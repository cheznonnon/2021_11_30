// Nekomimi Nina
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_nn_player_change( n_nn *p )
{

	if ( p->player_prev == p->player ) { return; }


	n_bmp            *b  = &p->bmp[ N_NN_BMP_PLAYER ];
	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];
	n_game_map       *m  =  mc->m;

	if ( p->player == N_NN_PLAYER_NINA )
	{

		n_game_rc_load_png2bmp_literal( b, "NN_BMP_0" );
		n_nn_scaler_big( p, b );

		mc->dash_max = p->dash_max;
		mc->jump_max = p->jump_max;

		m->mode &= ~N_GAME_MAP_MODE_XLOOP;
		m->mode |=  N_GAME_MAP_MODE_STOP;

	} else
	if ( p->player == N_NN_PLAYER_NONO )
	{

		n_game_rc_load_png2bmp_literal( b, "NN_BMP_0_1" );
		n_nn_scaler_big( p, b );

		mc->dash_max = p->dash_max * 2;
		mc->jump_max = p->jump_max * 2;

		m->mode &= ~N_GAME_MAP_MODE_STOP;
		m->mode |=  N_GAME_MAP_MODE_XLOOP;

	}


	p->player_prev = p->player;


	n_game_refresh_on();
	return;
}

void
n_nn_worldmap( n_nn *p, n_bool cache_only )
{

	if ( p->worldmap == n_false ) { return; }


	// [!] : Required : 200Mhz or faster CPU


	n_bmp      *b = &p->bmp[ N_NN_BMP_WORLD ];
	n_game_map *m = &p->map[ N_NN_MAP_MAIN ];


	// Bitmap

	static s32     x = 0;
	static s32     y = 0;
	static s32    sx = 0;
	static s32    sy = 0;
	static double rx = 0;
	static double ry = 0;

	if ( cache_only )
	{

		n_bmp_carboncopy( &m->map, b );
		n_bmp_flush_mixer( b, n_bmp_black, 0.2 );

		double map_sx = N_BMP_SX( b );
		double map_sy = N_BMP_SY( b );
		double frm_sx = (double) p->csx * 0.25;
		double frm_sy = (double) p->csy * 0.25;

		rx = frm_sx / map_sx;
		ry = frm_sy / map_sy;

		n_bmp_resampler( b, rx, ry );

		 x = (double) p->csx * 0.05;
		 y = (double) p->csy * 0.05;
		sx = N_BMP_SX( b );
		sy = N_BMP_SY( b );

		return;

	}


	// Draw

	n_bmp_blendcopy( b, p->mch[ N_NN_CHR_PLAYER ].c->main, 0,0,sx,sy, x,y, 0.5 );


	// Indicator

	int i = 0;
	while( 1 )
	{

		n_game_map_chara *mc = &p->mch[ i ];
		n_game_chara     *c  =  mc->c;

		double mx = (double) c->x / m->unit_sx * rx;
		double my = (double) c->y / m->unit_sy * ry;


		s32 size  = 3;
		u32 color = 0;

		if ( i == N_NN_CHR_PLAYER  ) { color = n_bmp_rgb( 255,  0,128 ); } else
		if ( i == N_NN_CHR_HLIFT_0 ) { color = n_bmp_rgb( 255,255,  0 ); } else
		if ( i == N_NN_CHR_HLIFT_1 ) { color = n_bmp_rgb(   0,255,255 ); } else
		if ( i == N_NN_CHR_HLIFT_2 ) { color = n_bmp_rgb( 255,  0,255 ); } else
		if ( i == N_NN_CHR_VLIFT   ) { color = n_bmp_rgb(   0,  0,255 ); } else
		if ( i == N_NN_CHR_BLOCK   ) { color = n_bmp_rgb( 150,100,150 ); } else
		if ( i >= N_NN_CHR_PIYO    ) { color = n_bmp_rgb( 255,200,  0 ); }

		s32 tx = x + mx - ( size / 2 );
		s32 ty = y + my - ( size / 2 );

		n_bmp_box( c->main, tx,ty, size,size, color );


		i++;
		if ( i >= N_NN_CHR_MAX ) { break; }
	}


	return;
}

void
n_nn_balloon( n_nn *p )
{

	if ( p->balloon == n_false ) { return; }


	n_bmp            *b  = &p->bmp[ N_NN_BMP_BALLOON ];
	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER  ];
	n_game_chara     *c  =  mc->c;


	const s32 sx = N_BMP_SX( b );
	const s32 sy = N_BMP_SX( b );
	const s32 mx = p->unit_mx;
	const s32 my = p->unit_my;


	// [!] : make a copy of a player object

	n_game_map_chara balloon_mc = *mc;
	n_game_chara     balloon_c  = *c;

	balloon_mc.c        = &balloon_c;
	balloon_mc.c->chara =  b;

	n_game_chara_src( &balloon_c, 0,0,sx,sy, mx,my );


	// [!] : movement engine

	{

		static double d = 0;

		balloon_mc.c->y -= sy - ( my * 2 );
		balloon_mc.c->y -= (double) ( sy * 0.5 ) * fabs( sin( 2.0 * M_PI * d ) );


		const  int    speed = 20;
		const  double step  = 0.01;
		static u32    tmr   = 0;

		if ( n_game_timer( &tmr, speed ) ) { d += step; }

	}


	balloon_mc.redraw = n_true;
	n_game_map_chara_draw_full( &balloon_mc, 0,0,0, N_BMP_EDGE_OUTER | N_BMP_EDGE_CROSS );


	return;
}

void
n_nn_graychip( n_nn *p, n_bool onoff )
{

	if ( onoff )
	{

		int i = 0;
		while( 1 )
		{

			n_bmp_carboncopy( &p->map[ i ].chip, &p->bmp[ N_NN_BMP_BACKUP + i ] );
			n_bmp_flush_grayscale( &p->map[ i ].chip );

			i++;
			if ( i >= N_NN_MAP_MAX ) { break; }
		}

	} else {

		int i = 0;
		while( 1 )
		{

			n_bmp_carboncopy( &p->bmp[ N_NN_BMP_BACKUP + i ], &p->map[ i ].chip );
			n_bmp_free( &p->bmp[ N_NN_BMP_BACKUP + i ] );

			i++;
			if ( i >= N_NN_MAP_MAX ) { break; }
		}

	}


	return;
}

void
n_nn_npc_turn( n_nn *p, int character_number )
{

	n_game_map_chara *mc = &p->mch[ character_number ];

	if ( mc->lr == N_GAME_MAP_CHARA_LEFT  ) { mc->lr = N_GAME_MAP_CHARA_RIGHT; } else
	if ( mc->lr == N_GAME_MAP_CHARA_RIGHT ) { mc->lr = N_GAME_MAP_CHARA_LEFT;  }

	return;
}

void
n_nn_npc_dash( n_nn *p, int character_number )
{

	n_game_map_chara *mc     = &p->mch[ N_NN_CHR_PLAYER ];
	n_game_chara     *c      =  mc->c;
	n_game_map_chara *npc_mc = &p->mch[ character_number ];
	n_game_chara     *npc_c  =  npc_mc->c;


	s32 px = npc_c->x;
	n_game_map_chara_dash( npc_mc, npc_mc->lr );


	if (
		( character_number >= N_NN_CHR_HLIFT_0 )
		&&
		( character_number <= N_NN_CHR_HLIFT_2 )
	)
	{

		//if ( npc_c->x == px ) { n_nn_npc_turn( p, character_number ); }


		int ret = n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_NOMOVE );

		if ( ret & N_GAME_MAP_CHARA_UP )
		{

			// Walk-On-Lift

//if ( mc->jump != 3 ) { n_game_hwndprintf_literal( "%d", mc->jump ); }

			if ( mc->jump == N_GAME_MAP_CHARA_JUMP_ON_FALL )
			{
				n_game_sound_loop( &p->snd[ N_NN_SND_WALK ] );
			}

			p->riding = character_number;
			mc->jump  = N_GAME_MAP_CHARA_JUMP_OFF;

			n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_UP );


			// Move-With-Lift

			s32 dx = npc_c->x - px;

			if ( dx < 0 ) { n_game_map_chara_fit( mc, abs( dx ), N_GAME_MAP_CHARA_LEFT  ); } else
			if ( dx > 0 ) { n_game_map_chara_fit( mc, abs( dx ), N_GAME_MAP_CHARA_RIGHT ); }

		}


		// Loop

		s32 npc_c_x = npc_c->x;

		n_game_map_chara_loop( npc_mc, N_GAME_MAP_CHARA_LOOP_LOOP );

		// [!] : multi-objects looping

		if ( p->riding == character_number )
		{

			s32 delta = c->x - npc_c_x;

			if (
				( ( npc_mc->lr == N_GAME_MAP_CHARA_LEFT  )&&( npc_c_x < npc_c->x ) )
				||
				( c->x < 0 )
			)
			{

				mc->redraw = npc_mc->redraw = n_true;

				npc_c->x = npc_mc->m->sx - n_posix_max_s32( abs( delta ) + c->sx, npc_c->sx );
				    c->x = npc_c->x + delta;

				n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_UP );

			} else
			if (
				( ( npc_mc->lr == N_GAME_MAP_CHARA_RIGHT )&&( npc_c_x > npc_c->x ) )
				||
				( ( c->x + c->sx ) >= mc->m->sx )
			)
			{
//n_game_hwndprintf_literal( "Lift #%d : %d", p->riding, npc_c->x );

				mc->redraw = npc_mc->redraw = n_true;

				npc_c->x = abs( delta );
				    c->x = npc_c->x + delta;

				n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_UP );

			}

		}
//if ( character_number == N_NN_CHR_HLIFT_0 ) { n_game_hwndprintf_literal( "%d", npc_mc->lr ); }

		{
			s32 x = 0;
			if ( npc_mc->lr & N_GAME_MAP_CHARA_LEFT  )
			{
				x -= npc_mc->dash_cur;
			} else
			if ( npc_mc->lr & N_GAME_MAP_CHARA_RIGHT )
			{
				x += npc_mc->dash_cur + npc_mc->c->sx;
			}

			if ( n_false == n_nn_rule_is_movable_offset( p, character_number, x, 0 ) )
			{
				n_nn_npc_turn( p, character_number );
				if ( npc_mc->lr & N_GAME_MAP_CHARA_RIGHT )
				{
					npc_c->x += p->zoom;
				}
			}
		}

	} else
	if ( character_number == N_NN_CHR_BLOCK )
	{

		int ret = n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_NOMOVE );

		if ( ret & N_GAME_MAP_CHARA_UP )
		{

			// Walk-On-Lift : prevent annoy quick moving

			if ( npc_c->y >= ( c->y + c->sy - c->my - mc->jump_step ) )
			{

				if ( mc->jump == N_GAME_MAP_CHARA_JUMP_ON_FALL )
				{
					n_game_sound_loop( &p->snd[ N_NN_SND_WALK ] );
				}

				p->riding = character_number;
				mc->jump  = N_GAME_MAP_CHARA_JUMP_OFF;

				n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_UP );

			}

		} else
		if ( ret & N_GAME_MAP_CHARA_LEFT )
		{

			// [!] : push from left to right

			if ( n_nn_rule_is_movable_offset( p, character_number, npc_c->sx,0 ) )
			{
				n_game_map_chara_collision( npc_mc, mc, N_GAME_MAP_CHARA_RIGHT );
			} else {
				npc_c->x = px;
				n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_LEFT  );
			}

		} else
		if ( ret & N_GAME_MAP_CHARA_RIGHT )
		{

			// [!] : push from right to left

			if ( n_nn_rule_is_movable_offset( p, character_number, 0,0 ) )
			{
				n_game_map_chara_collision( npc_mc, mc, N_GAME_MAP_CHARA_LEFT  );
			} else {
				npc_c->x = px;
				n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_RIGHT );
			}

		}

	} else
	if ( character_number >= N_NN_CHR_PIYO )
	{

		if ( px == npc_c->x )
		{
			n_nn_npc_turn( p, character_number );

			if ( npc_mc->lr == N_GAME_MAP_CHARA_LEFT )
			{
				npc_mc->c->x -= npc_mc->c->mx;
			} else
			if ( npc_mc->lr == N_GAME_MAP_CHARA_RIGHT )
			{
				npc_mc->c->x += npc_mc->c->mx;
			}
		}

//return;

		if ( p->dokan ) { return; }


		// [!] : shake-off

		if ( n_game_input_loop( &p->input, 'X' ) )
		{
			p->riding_piyo = 0;
			return;
		}


		if ( mc->jump == N_GAME_MAP_CHARA_JUMP_OFF ) { return; }


		s32 mx = npc_c->mx; npc_c->mx = 0;
		s32 my = npc_c->my; npc_c->my = 0;

		int ret = n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_NOMOVE );

		npc_c->mx = mx;
		npc_c->my = my;


		if (
			(
				( p->riding_piyo == 0 )
				||
				( p->riding_piyo == character_number )
			)
			&&
			( ret & N_GAME_MAP_CHARA_UP )
		)
		{
//n_win_debug_count( game.hwnd );

			// [!] : remember a riding chick

			p->riding_piyo = character_number;


			mc->lr  = npc_mc->lr;
			c->srcx = p->srcx_ride;


			// Walk-On-Lift

			if ( mc->jump == N_GAME_MAP_CHARA_JUMP_ON_FALL )
			{
				n_game_sound_loop( &p->snd[ N_NN_SND_WALK ] );
			}

			p->riding = character_number;
			mc->jump  = N_GAME_MAP_CHARA_JUMP_OFF;


			// [!] : Input Center : formally debug function

			if ( n_win_is_input( VK_UP    ) ) { npc_c->y -= 2 * p->zoom; }
			if ( n_win_is_input( VK_DOWN  ) ) { npc_c->y += 2 * p->zoom; }
			if ( n_win_is_input( VK_LEFT  ) ) { npc_mc->lr = N_GAME_MAP_CHARA_LEFT ; }
			if ( n_win_is_input( VK_RIGHT ) ) { npc_mc->lr = N_GAME_MAP_CHARA_RIGHT; }


			// [!] : don't use n_game_map_chara_collision()
			//
			//	flicker happens when only a character is hit with blocks

			//n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_UP   );
			//n_game_map_chara_collision( npc_mc, mc, N_GAME_MAP_CHARA_DOWN );


			// [!] : prevent quick move

			{
				int is_left  = n_game_map_chara_wall( mc, N_GAME_MAP_CHARA_LEFT  );
				int is_right = n_game_map_chara_wall( mc, N_GAME_MAP_CHARA_RIGHT );
//n_game_hwndprintf_literal( " %d %d ", is_left, is_right );

				if ( ( is_left  == 0 )&&( npc_mc->lr == N_GAME_MAP_CHARA_LEFT  ) )
				{
//n_game_hwndprintf_literal( " Left : %d %d ", is_left, is_right );
					npc_mc->lr = N_GAME_MAP_CHARA_RIGHT;
				}
				if ( ( is_right == 0 )&&( npc_mc->lr == N_GAME_MAP_CHARA_RIGHT ) )
				{
//n_game_hwndprintf_literal( " Right : %d %d ", is_left, is_right );
					npc_mc->lr = N_GAME_MAP_CHARA_LEFT ;
				}
			}


			s32 offset = ( ( 96 - 8 ) * p->zoom );

			c->x = npc_c->x;
			c->y = npc_c->y;

			n_game_map_chara_fit(     mc, offset, N_GAME_MAP_CHARA_UP   );

			npc_c->x = c->x;
			npc_c->y = c->y;

			n_game_map_chara_fit( npc_mc, offset, N_GAME_MAP_CHARA_DOWN );

		}


		// Loop

		s32 npc_c_x = npc_c->x;

		n_game_map_chara_loop( npc_mc, N_GAME_MAP_CHARA_LOOP_LOOP );

		// [!] : multi-objects looping

		if ( p->riding == character_number )
		{

			s32 delta = c->x - npc_c_x;

			if (
				( ( npc_mc->lr == N_GAME_MAP_CHARA_LEFT  )&&( npc_c_x < npc_c->x ) )
				||
				( c->x < 0 )
			)
			{
//n_game_hwndprintf_literal( " ! " );

				mc->redraw = npc_mc->redraw = n_true;

				npc_c->x = npc_mc->m->sx - n_posix_max_s32( abs( delta ) + c->sx, npc_c->sx );
				    c->x = npc_c->x + delta;

				n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_UP );

			} else
			if (
				( ( npc_mc->lr == N_GAME_MAP_CHARA_RIGHT )&&( npc_c_x > npc_c->x ) )
				||
				( ( c->x + c->sx ) >= mc->m->sx )
			)
			{
//n_game_hwndprintf_literal( " ! " );

				mc->redraw = npc_mc->redraw = n_true;

				npc_c->x = abs( delta );
				    c->x = npc_c->x + delta;

				n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_UP );

			}

		}

	}// else


/*
int ret = n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_NOMOVE );
if ( ret != N_GAME_MAP_CHARA_NOMOVE )
{
	n_game_hwndprintf_literal( "%lu : %d : Y = %d", n_posix_tickcount(), ret, c->y );
}
*/
	return;
}

void
n_nn_npc_jump( n_nn *p, int character_number )
{

	n_game_map_chara *mc     = &p->mch[ N_NN_CHR_PLAYER ];
	//n_game_chara     *c      =  mc->c;
	n_game_map_chara *npc_mc = &p->mch[ character_number ];
	n_game_chara     *npc_c  =  npc_mc->c;


	if ( character_number == N_NN_CHR_VLIFT )
	{

		// [!] : emulate updown movement

//npc_mc->dash_step = 8;

		if ( npc_mc->jump == N_GAME_MAP_CHARA_JUMP_OFF )
		{

			npc_mc->jump = N_GAME_MAP_CHARA_JUMP_ON_RISE;

		} else
		if ( npc_mc->jump == N_GAME_MAP_CHARA_JUMP_ON_RISE )
		{

			if ( n_nn_rule_is_movable_offset( p, character_number, 0, -npc_c->sy ) )
			{
				n_game_map_chara_fit( npc_mc, npc_mc->dash_step, N_GAME_MAP_CHARA_UP );
			} else {
				npc_mc->jump = N_GAME_MAP_CHARA_JUMP_ON_FALL;
			}

		} else
		if ( npc_mc->jump == N_GAME_MAP_CHARA_JUMP_ON_FALL )
		{

			if ( n_nn_rule_is_movable_offset( p, character_number, 0, npc_c->sy ) )
			{
				n_game_map_chara_fit( npc_mc, npc_mc->dash_step, N_GAME_MAP_CHARA_DOWN );
			} else {
				npc_mc->jump = N_GAME_MAP_CHARA_JUMP_OFF;
			}

		}

		npc_mc->redraw = n_true;


		// [x] : fall-through will occur when moving value is higher than object's height

		int ret = n_game_map_chara_collision( mc, npc_mc, N_GAME_MAP_CHARA_UP );

		if ( ret & N_GAME_MAP_CHARA_UP )
		{

			p->riding = n_true;

			if ( mc->jump == N_GAME_MAP_CHARA_JUMP_ON_FALL )
			{
				n_game_sound_loop( &p->snd[ N_NN_SND_WALK ] );
			}

			mc->jump = N_GAME_MAP_CHARA_JUMP_OFF;

		}

	} else
	if ( character_number >= N_NN_CHR_PIYO )
	{

		n_game_map_chara_jump   ( npc_mc );
		n_game_map_chara_gravity( npc_mc );

	}// else



//n_game_hwndprintf_literal( "%d", mc->jump );
	return;
}

void
n_nn_npc_piyo_collision( n_nn *p, int character_number )
{

	int i = 0;
	while( 1 )
	{

		n_game_chara *c_f = p->mch[ character_number + i ].c;

		int j = i;
		while( 1 )
		{

			n_game_chara *c_t = p->mch[ character_number + j ].c;

			if ( n_game_chara_is_hit( c_f, c_t ) )
			{
				n_nn_npc_turn( p, character_number + i );
				n_nn_npc_turn( p, character_number + j );
			}

			j++;
			if ( j >= N_NN_PIYO_MAX ) { break; }
		}


		i++;
		if ( i >= N_NN_PIYO_MAX ) { break; }
	}


	return;
}

void
n_nn_npc_piyo( n_nn *p, int character_number )
{

	int i = 0;
	while( 1 )
	{

		n_nn_npc_dash( p, character_number + i );
		n_nn_npc_jump( p, character_number + i );


		n_game_map_chara *npc_mc = &p->mch[ character_number + i ];
		n_game_chara     *npc_c  =  npc_mc->c;

		n_nn_npc_piyo_collision( p, character_number );

		if ( n_game_timer( &npc_mc->dash_frame_timer, npc_mc->dash_frame_msec ) )
		{
			npc_c->srcx += p->unit;
			if ( npc_c->srcx >= N_BMP_SX( npc_c->chara ) ) { npc_c->srcx = 0; }
		}

		n_game_map_chara_loop( npc_mc, N_GAME_MAP_CHARA_LOOP_LOOP );

		npc_mc->dash_max  = 10;
		npc_mc->dash_step = n_game_random(   2 ) + 2;
		npc_mc->jump_max  = n_game_random( 100 );
		npc_mc->jump_step = n_game_random(   6 );

		npc_mc->dash_frame_msec = 500 + ( npc_mc->dash_cur * npc_mc->jump_cur );


		i++;
		if ( i >= N_NN_PIYO_MAX ) { break; }
	}


	return;
}

