



#include "../../nonnon/win32/win.c"
#include "../../nonnon/win32/win_button.c"

#include "../../nonnon/project/macro.c"




void
n_dwm_blurredwindow_enable( HWND hwnd )
{

	HMODULE hmod = LoadLibrary( n_posix_literal( "Dwmapi.dll" ) );
	if ( hmod == NULL ) { return; }

	{

		// dwmapi.h

		const int n_DWM_BB_ENABLE                = 0x00000001;
		//const int n_DWM_BB_BLURREGION            = 0x00000002;
		//const int n_DWM_BB_TRANSITIONONMAXIMIZED = 0x00000004;

		typedef struct _DWM_BLURBEHIND {

			DWORD dwFlags;
			BOOL  fEnable;
			HRGN  hRgnBlur;
			BOOL  fTransitionOnMaximized;

		} DWM_BLURBEHIND, *PDWM_BLURBEHIND;


		FARPROC func = GetProcAddress( hmod, "DwmEnableBlurBehindWindow" );
		if ( func != NULL )
		{

			DWM_BLURBEHIND db = { n_DWM_BB_ENABLE, TRUE, NULL, TRUE };

			func( hwnd, &db );

		}

	}

	{

		// uxtheme.h

		typedef struct _MARGINS {

			int cxLeftWidth;
			int cxRightWidth;
			int cyTopHeight;
	  		int cyBottomHeight;

		} MARGINS, *PMARGINS;


		FARPROC func = GetProcAddress( hmod, "DwmExtendFrameIntoClientArea" );
		if ( func != NULL )
		{


			MARGINS ms = { -1,-1,-1,-1 };

			func( hwnd, &ms );

		}

	}


	FreeLibrary( hmod );


	return;
}

LRESULT
n_dwm_defwndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	HMODULE hmod = LoadLibrary( n_posix_literal( "Dwmapi.dll" ) );
	FARPROC func = GetProcAddress( hmod, "DwmDefWindowProc" );


	LRESULT hr = 0;

	if ( func != NULL )
	{
		func( hwnd, msg, wparam, lparam, &hr );
	} else {
		hr = DefWindowProc( hwnd, msg, wparam, lparam );
	}


	FreeLibrary( hmod );


	return hr;
}

void
n_dwm_box( HWND hwnd, s32 x, s32 y, s32 sx, s32 sy, COLORREF color )
{

	RECT r = n_win_rect_set( NULL, x,y,sx,sy );
	n_win_box( hwnd, NULL, &r, color );


	return;
}

void
n_dwm_mask( HWND hwnd, s32 x, s32 y, s32 sx, s32 sy )
{

	HDC hdc = GetDC( hwnd );

	ExcludeClipRect( hdc, x,y,x+sx,y+sy );

	ReleaseDC( hwnd, hdc );


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_button button;


	switch( msg ) {


	case WM_CREATE :


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );


		n_win_button_zero( &button );
		n_win_button_init( &button, hwnd, "Button", PBS_NORMAL );

		n_win_move_simple( button.hwnd, 10,10,100,100, n_true );


		// Display

		//SetClassLong( hwnd, GCL_HBRBACKGROUND, (LONG) 0 );

		//n_dwm_blurredwindow_enable( hwnd );
		n_win_dwm_transparent_on( hwnd );

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_ERASEBKGND :

		return TRUE;

	break;
	case WM_PAINT :

		// [!] : black color will be transparent

		n_dwm_box( hwnd,   0,  0,200,200, 0x00000000 );
		//n_dwm_box( hwnd,  10, 10,100,100, 0xffffffff );

	break;
	case WM_NCPAINT :

		//n_dwm_mask( hwnd,  10, 10,100,100 );

	break;


	case WM_NCCALCSIZE :
break;
		// [Mechanism]
		//
		//	[ In ]
		//
		//	Member       | Size       | Coord  | Result
		//	------------------------------------------------------
		//	p->rgrc[ 0 ] | window new | screen |  18  17 284 301 == GetWindowRect()
		//	p->rgrc[ 1 ] | window old | window |  18  17 284 301 == GetWindowRect()
		//	p->rgrc[ 2 ] | client new | window |  22  40 279 297 == relative + GetClientRect()

		if ( wparam )
		{

			//NCCALCSIZE_PARAMS *p = (void*) lparam;

//n_win_rect_debug( &p->rgrc[ 0 ] );
//n_win_rect_debug( &p->rgrc[ 1 ] );
//n_win_rect_debug( &p->rgrc[ 2 ] );


			//n_win_rect_set( &p->rgrc[ 0 ], 30,30,200,200 );

			//return WVR_VALIDRECTS;
			//return 0;

		}

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_button_exit( &button );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_button_proc( hwnd, msg, wparam, lparam, &button );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

