


//#define UNICODE




#include "../../nonnon/win32/win.c"

#include "../../nonnon/neutral/txt.c"

#include "../../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_txt txt;


	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 256,256, N_WIN_SET_CENTERING );

		n_txt_zero( &txt );
		n_txt_new( &txt );

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SETTINGCHANGE :
	{

		// [Mechanism] : Win8.1
		//
		//	theme "Windows" to "High Contrast White"
		//
		//	DEC  | HEX    | SPI
		//	------------------------------------
		//	67   | 0x0043 | SPI_SETHIGHCONTRAST
		//	4131 | 0x1023 | SPI_SETFLATMENU
		//	20   | 0x0014 | SPI_SETDESKWALLPAPER
		//
		//	theme "High Contrast White" to "Windows"
		//
		//	DEC  | HEX    | SPI
		//	------------------------------------
		//	67   | 0x0043 | SPI_SETHIGHCONTRAST
		//	4131 | 0x1023 | SPI_SETFLATMENU

		n_posix_char str[ 100 ];
		n_posix_sprintf_literal( str, "%d : %04x", wparam, wparam );
		n_txt_set( &txt, txt.sy, str );	

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_txt_save_literal( &txt, "ret.txt" );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

