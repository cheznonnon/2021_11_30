// Nonnon COM : IPropertyNotifySink
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed




#ifndef _H_NONNON_WIN32_COM_IPROPERTYNOTIFYSINK
#define _H_NONNON_WIN32_COM_IPROPERTYNOTIFYSINK




#include "com.c"




HRESULT __stdcall
n_IPropertyNotifySink_IUnknown_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{
N_COM_DEBUG_LISTBOX_SET_A( "IPropertyNotifySink_IUnknown_QueryInterface" );


	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID d = n_com_guid( n_guid_IID_IDispatch );
	GUID p = n_com_guid( n_guid_IID_IPropertyNotifySink );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &d ) )
		||
		( IsEqualGUID( iid, &p ) )
	)
	{

		if ( ppvObject != NULL ) {  (*ppvObject) = _this; }

		return S_OK;
	}


	return E_NOINTERFACE;
}




HRESULT __stdcall
n_IPropertyNotifySink_OnChanged( void *_this, DISPID dispID )
{
N_COM_DEBUG_LISTBOX_SET_A( "IPropertyNotifySink_OnChanged" );


	n_posix_char str[ 100 ];

	sprintf( str, "%X", (unsigned int) dispID );

	N_COM_DEBUG_LISTBOX_SET_A( str );


	return S_OK;
}

HRESULT __stdcall
n_IPropertyNotifySink_OnRequestEdit( void *_this, DISPID dispID )
{
N_COM_DEBUG_LISTBOX_SET_A( "IPropertyNotifySink_OnRequestEdit" );


	n_posix_char str[ 100 ];

	sprintf( str, "%X", (unsigned int) dispID );

	N_COM_DEBUG_LISTBOX_SET_A( str );


	return S_OK;
}




const void *n_IPropertyNotifySink_Vtbl[] = {

	n_IPropertyNotifySink_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,

	n_IPropertyNotifySink_OnChanged,
	n_IPropertyNotifySink_OnRequestEdit

};


#endif // _H_NONNON_WIN32_COM_IPROPERTYNOTIFYSINK

