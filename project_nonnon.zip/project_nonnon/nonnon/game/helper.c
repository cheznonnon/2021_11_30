// Nonnon Game
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_GAME_HELPER
#define _H_NONNON_WIN32_GAME_HELPER




#include "../neutral/bmp.c"
#include "../neutral/random.c"




inline n_posix_bool
n_game_timer( u32 *prv, u32 interval )
{

	u32 cur = n_posix_tickcount();
	u32 msec;


	if ( (*prv) > cur )
	{
		msec = cur + ( 0xffff - (*prv) );
	} else {
		msec = cur - (*prv);
	}

	if ( msec >= interval )
	{
		(*prv) = cur;

		return n_posix_true;
	}


	return n_posix_false;
}

#define n_game_random( range ) n_random_range( range )

inline u32
n_game_randomcolor( void )
{

	u32 color = n_bmp_rgb
	(
		n_game_random( 256 ),
		n_game_random( 256 ),
		n_game_random( 256 )
	);


	return color;
}

inline s32
n_game_centering( s32 a, s32 b )
{

	// [!] : ( ( a / 2 ) - ( b / 2 ) ) == ( ( a - b ) / 2 )

	return ( a - b ) / 2;
}


#endif // _H_NONNON_WIN32_GAME_HELPER

