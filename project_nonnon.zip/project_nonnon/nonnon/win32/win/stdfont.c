// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_STDFONT
#define _H_NONNON_WIN32_WIN_STDFONT




#include "./_debug.c"
#include "./font.c"




HFONT
n_win_stdfont_hfont( void )
{

	// [Needed] : n_win_font_exit( hfont );


	// [!] : Compatibility : Vista : cb is different
	//
	//	currently not supported, but no problems

	const int cb = sizeof( NONCLIENTMETRICS );


	NONCLIENTMETRICS ncm; ZeroMemory( &ncm, cb );

	ncm.cbSize = cb;

	n_posix_bool ret = SystemParametersInfo( SPI_GETNONCLIENTMETRICS, cb, &ncm, 0 );
	if ( ret == n_posix_false ) { return NULL; }


	return n_win_font_logfont2hfont( &ncm.lfMessageFont );
}

void
n_win_stdfont_init( HWND *hgui, s64 count )
{

	// [Mechanism]
	//
	//	NONCLIENTMETRICS
	//	+ Explorer uses this setting
	//	+ Win95 accessibility color scheme
	//	+ Desktop Theme (including uxtheme)
	//
	//	DEFAULT_GUI_FONT
	//	+ dialog based applications use this font
	//	+ Win2000 or later : this can be replaced by DPI setting


	s64 i = 0;
	while( 1 )
	{

		HFONT hf = n_win_font_get( hgui[ i ] );
		n_win_font_exit( hf );

		hf = n_win_stdfont_hfont();
		n_win_font_set( hgui[ i ], hf, n_posix_false );


		i++;
		if ( i >= count ) { break; }
	}


	return;
}

void
n_win_stdfont_exit( HWND *hgui, s64 count )
{

	s64 i = 0;
	while( 1 )
	{

		HFONT hf = n_win_font_get( hgui[ i ] );
		n_win_font_exit( hf );

		i++;
		if ( i >= count ) { break; }
	}


	return;
}


#endif // _H_NONNON_WIN32_WIN_STDFONT

