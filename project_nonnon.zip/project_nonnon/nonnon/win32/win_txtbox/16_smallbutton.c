// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_smallbutton_direct_embed( n_win_txtbox *p, n_win_smallbutton_direct *sb, int index )
{
//return;

	if ( p == NULL ) { return; }


	if ( ( index < 0 )||( index >= N_WIN_TXTBOX_SMALLBUTTON_MAX ) ) { return; }


	p->smallbutton_is_used = n_posix_true;
	n_win_timer_init( p->hwnd, p->smallbutton_timer, 33 );


	p->smallbutton[ index ] = sb;


	n_win_txtbox_metrics( p );


	index = n_posix_max( 1, index + 1 );

	s32 ix,iy,isx,isy; n_win_location( p->hwnd, &ix,&iy,&isx,&isy );

	ix = iy = 0;

	{

		const s32 border = 2 * p->scale;

		s32 btn = isy - ( border * 2 );

		//if ( p->debug_onoff == n_posix_false )
		{
			s32 bx = bx = ( ix + isx ) - border - ( btn * index );
			s32 by = iy + border;

			sb->x  = bx;
			sb->y  = by;
			sb->sx = btn;
			sb->sy = btn;

			sb->bmp_canvas = &p->bmp;

//if ( index == 0 ) { n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d ", sb->x, sb->y, sb->sx, sb->sy ); }
		}

		p->smallbutton_margin = btn * index;

	}


	return;
}

void
n_win_txtbox_smallbutton_direct_rearrange( n_win_txtbox *p, n_win_smallbutton_direct *sb, int index )
{
//return;

	if ( p == NULL ) { return; }


	if ( ( index < 0 )||( index >= N_WIN_TXTBOX_SMALLBUTTON_MAX ) ) { return; }


	p->smallbutton[ index ] = sb;


	index = n_posix_max( 1, index + 1 );

	s32 ix,iy,isx,isy; n_win_location( p->hwnd, &ix,&iy,&isx,&isy );

	ix = iy = 0;

	{

		const s32 border = 2 * p->scale;

		s32 btn = isy - ( border * 2 );

		//if ( p->debug_onoff == n_posix_false )
		{
			s32 bx = bx = ( ix + isx ) - border - ( btn * index );
			s32 by = iy + border;

			sb->x  = bx;
			sb->y  = by;
			sb->sx = btn;
			sb->sy = btn;

			sb->bmp_canvas = &p->bmp;

//if ( index == 0 ) { n_win_txtbox_hwndprintf_literal( p, " %d %d %d %d ", sb->x, sb->y, sb->sx, sb->sy ); }
		}

		p->smallbutton_margin = btn * index;

	}


	return;
}

n_posix_bool
n_win_txtbox_smallbutton_direct_is_hovered( n_win_txtbox *p )
{
//return 0;

	n_posix_bool ret = n_posix_false;

	int i = 0;
	while( p->smallbutton_is_used )
	{//break;

		n_win_smallbutton_direct *sb = p->smallbutton[ i ];

		if ( sb != NULL )
		{
			if ( sb->show_onoff )
			{
				if ( sb->state & N_WIN_SMALLBUTTON_DIRECT_HOVERED )
				{
					ret = n_posix_true;
					break;
				}
			}
		}

		i++;
		if ( i >= N_WIN_TXTBOX_SMALLBUTTON_MAX ) { break; }
	}


	return ret;
}

void
n_win_txtbox_smallbutton_refresh( n_win_txtbox *p )
{
//return;

	if ( p->smallbutton_is_used == n_posix_false ) { return; }


	HDC hdc_main = GetDC( p->hwnd );
	HDC hdc_cmpt = CreateCompatibleDC( hdc_main );

	HBITMAP hbmp_old = SelectObject( hdc_cmpt, p->hbmp );


	int i = 0;
	while( 1 )
	{//break;

		n_win_smallbutton_direct *sb = p->smallbutton[ i ];

		if ( sb != NULL )
		{
			if ( sb->show_onoff )
			{
				BitBlt( hdc_main, sb->x,sb->y,sb->sx,sb->sy, hdc_cmpt, sb->x,sb->y, SRCCOPY );
			}
		}

		i++;
		if ( i >= N_WIN_TXTBOX_SMALLBUTTON_MAX ) { break; }
	}


	SelectObject( hdc_cmpt, hbmp_old );

	DeleteObject( hdc_cmpt );
	ReleaseDC( p->hwnd, hdc_main );


	return;
}


