// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_fade_go( n_win_txtbox *p, n_bmp_fade *fade )
{

	u32 color;
	if ( fade->color_fg == n_bmp_white )
	{
		color = n_bmp_black;
	} else {
		color = n_bmp_white;
	}

	fade->stop = n_posix_true;

	n_bmp_fade_go( fade, color );


	return;
}

void
n_win_txtbox_move( n_win_txtbox *p, s32 x, s32 y, s32 sx, s32 sy, n_posix_bool redraw )
{

	ShowWindow( p->hwnd, SW_HIDE );

	n_win_move( p->hwnd, x,y,sx,sy, redraw );

	ShowWindow( p->hwnd, SW_NORMAL );


	return;
}

void
n_win_txtbox_move_simple( n_win_txtbox *p, s32 x, s32 y, s32 sx, s32 sy, n_posix_bool redraw )
{

	ShowWindow( p->hwnd, SW_HIDE );

	n_win_move_simple( p->hwnd, x,y,sx,sy, redraw );

	ShowWindow( p->hwnd, SW_NORMAL );


	return;
}

void
n_win_txtbox_linenumber_cache( n_win_txtbox *p )
{

	if ( n_posix_false == ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ) ) { return; }


	s32 sx = p->number_pxl_sx / 6;
	s32 sy = p->cell_pxl_sy;

	int i = 0;
	while( 1 )
	{

		RECT rect = n_win_rect_set( NULL, 0, 0, sx, sy );
		n_posix_char str[ 2 ] = { n_posix_literal( '0' ) + i, N_STRING_CHAR_NUL };

		HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( p->hwnd, sx, sy );

		SetBkColor  ( hdc, p->color_back_linenum1 );
		SetTextColor( hdc, p->color_text_linenum1 );

		// [Needed] : some glyphs : the last line is no-touched
		n_bmp_flush( &n_gdi_doublebuffer_32bpp_instance.bmp, n_bmp_colorref2argb( p->color_back_linenum1 ) );

		DrawText( hdc, str, 1, &rect, p->drawtext_modes );

		n_bmp_free( &p->bmp_linenumber[ i ] );
		n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, &p->bmp_linenumber[ i ] );

//n_posix_char name[ 100 ]; n_posix_sprintf_literal( name, "%s.bmp", str );
//n_bmp_save( &bmp[ i ], name );

		n_gdi_doublebuffer_32bpp_cleanup( &n_gdi_doublebuffer_32bpp_instance );

		i++;
		if ( i >= 10 ) { break; }


	}


	return;
}

// internal
n_bmp*
n_win_txtbox_glyph_cache
(
	n_win_txtbox *p,
	         int  index,
	n_posix_bool  is_striped,
	n_posix_bool  is_highlighted
)
{
//return NULL;

	if ( ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
	{
		return NULL;
	}


	n_bmp *bmp;

	if ( is_highlighted )
	{
		bmp = &p->cache_bmp_hilt[ index ];
	} else
	if ( p->is_grayed )
	{
		bmp = &p->cache_bmp_gray[ index ];
	} else
	if ( is_striped )
	{
		bmp = &p->cache_bmp_strp[ index ];
	} else {
		bmp = &p->cache_bmp_main[ index ];
	}

	if ( NULL != N_BMP_PTR( bmp ) ) { return bmp; }


	n_posix_char str[ 2 ] = { index, N_STRING_CHAR_NUL };

	s32 sx;
	s32 sy = p->cell_pxl_sy;

	if ( p->is_font_monospace )
	{
		if ( n_win_txtbox_is_fullwidth( index ) )
		{
			sx = p->size_fullwidth.cx;
		} else {
			sx = p->size_halfwidth.cx;
		}
	} else {
		// [x] : currently broken

		SIZE size = n_win_txtbox_size_text( p, str );
		sx = size.cx;
		sy = size.cy;
	}

	RECT rect = { 0, 0, sx, sy };


	HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( p->hwnd, sx, sy );


	COLORREF bg;
	COLORREF fg;

	if ( is_highlighted )
	{
		bg = p->color_back_selected;
		fg = p->color_text_selected;
	} else
	if ( p->is_grayed )
	{
		bg = p->color_back_disabled;
		fg = p->color_text_noselect;
	} else
	if ( is_striped )
	{
		bg = p->color_back_striping;
		fg = p->color_text_noselect;
	} else {
		bg = p->color_back_noselect;
		fg = p->color_text_noselect;
	}

	SetBkColor  ( hdc, bg & 0x00ffffff );
	SetTextColor( hdc, fg & 0x00ffffff );


	// [Needed] : some glyphs : the last line is no-touched
	n_bmp_flush( &n_gdi_doublebuffer_32bpp_instance.bmp, n_bmp_colorref2argb( bg ) );

	DrawText( hdc, str, 1, &rect, p->drawtext_modes | DT_CENTER );


	n_bmp_free( bmp );
	n_bmp_carboncopy( &n_gdi_doublebuffer_32bpp_instance.bmp, bmp );

//if ( index == n_posix_literal( 'g' ) ) { n_bmp_save_literal( bmp, "g.bmp" ); }


	n_gdi_doublebuffer_32bpp_cleanup( &n_gdi_doublebuffer_32bpp_instance );


	// Debug Center

	//n_bmp_flush( bmp, n_bmp_rgb( 0,200,255 ) );


	return bmp;
}

void
n_win_txtbox_glyph_cache_reset( n_win_txtbox *p )
{
//return;

	if ( ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )||( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
	{
		return;
	}


	int i = 0;
	while( 1 )
	{
		n_bmp_free( &p->cache_bmp_main[ i ] );
		n_bmp_free( &p->cache_bmp_strp[ i ] );
		n_bmp_free( &p->cache_bmp_hilt[ i ] );
		n_bmp_free( &p->cache_bmp_gray[ i ] );

		i++;
		if ( i >= p->cache_limit ) { break; }
	}


	return;
}

n_posix_char*
n_win_txtbox_eol_string_get( n_win_txtbox *p )
{

	n_posix_char *eol_str = N_STRING_EMPTY;


	if ( n_string_is_empty( p->eol_mark ) ) { return eol_str; }


	if ( n_string_is_same_literal( "auto", p->eol_mark ) )
	{
#ifdef UNICODE
		eol_str = n_posix_literal( "\x21a9" );
#else  // #ifdef UNICODE
		eol_str = n_posix_literal( "<" );
#endif // #ifdef UNICODE
	} else {
		eol_str = p->eol_mark;
	}


	return eol_str;
}

void
n_win_txtbox_previous( n_win_txtbox *p )
{

	p->prv_oneline_scroll = p->scroll_pxl_tabbed_x;

	p->prv_sel_x  = p->select_cch_x;
	p->prv_sel_y  = p->select_cch_y;
	p->prv_sel_sx = p->select_cch_sx;
	p->prv_sel_sy = p->select_cch_sy;
	p->prv_txt_sy = p->txt.sy;
	p->prv_drag   = p->shift_dragging;


	return;
}

void
n_win_txtbox_previous_calc( n_win_txtbox *p, s32 *ret__y, s32 *ret_sy )
{

	// [!] : this modulue is used for cascading like carrage-return


	// [!] : Slow Mode

	s32  y = N_WIN_TXTBOX_NOT_SELECTED;
	s32 sy = N_WIN_TXTBOX_NOT_SELECTED;


	// [!] : Fast Mode

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d : %d ", p->prv_sel_y, p->select_cch_y, p->prv_sel_sy, p->select_cch_sy, p->scroll_cch_tabbed_y );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_txt_sy, p->txt.sy );

	if ( p->prv_txt_sy > p->txt.sy )
	{
		//
	} else
	if (
		( p->prv_sel_y == p->select_cch_y )
		&&
		( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
	)
	{
		 y = p->select_cch_y;
		sy = 1;
	}


	if ( ret__y != NULL ) { (*ret__y) =  y; }
	if ( ret_sy != NULL ) { (*ret_sy) = sy; }


	return;
}

void
n_win_txtbox_previous_calc_selected( n_win_txtbox *p, s32 *ret__y, s32 *ret_sy )
{

	// [!] : Slow Mode

	s32  y = N_WIN_TXTBOX_NOT_SELECTED;
	s32 sy = N_WIN_TXTBOX_NOT_SELECTED;


	// [!] : Fast Mode

//n_win_txtbox_hwndprintf_literal( p, " %d %d : %d %d : %d ", p->prv_sel_y, p->select_cch_y, p->prv_sel_sy, p->select_cch_sy, p->scroll_cch_tabbed_y );
//n_win_txtbox_hwndprintf_literal( p, " %d %d ", p->prv_txt_sy, p->txt.sy );

	if ( p->prv_txt_sy > p->txt.sy )
	{
		//
	} else
	if (
		( p->prv_sel_y == p->select_cch_y )
		&&
		( ( p->prv_sel_sy == 1 )&&( p->select_cch_sy == 1 ) )
	)
	{
		 y = p->select_cch_y;
		sy = 1;
	} else {
		s32 fy = n_posix_min_s32( p->prv_sel_y, p->select_cch_y );
		s32 ty = n_posix_max_s32( p->prv_sel_y + p->prv_sel_sy, p->select_cch_y + p->select_cch_sy );

		 y = fy;
		sy = ty - fy;
	}


	if ( ret__y != NULL ) { (*ret__y) =  y; }
	if ( ret_sy != NULL ) { (*ret_sy) = sy; }


	return;
}

void
n_win_txtbox_cursor_add( n_win_txtbox *p, n_posix_char *idc )
{

	n_win_cursor_add( p->hwnd, idc );
	n_win_cursor_add(    NULL, idc );


	return;
}

void
n_win_txtbox_on_setcursor( n_win_txtbox *p )
{

	// [x] : static ownerdraw and disabled controls are excluded;

	if ( n_posix_false == ( p->style & N_WIN_TXTBOX_STYLE_EDITBOX ) )
	{

		n_win_txtbox_cursor_add( p, IDC_ARROW );

	} else
	if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_NOIBEAM )
	{

		n_win_txtbox_cursor_add( p, IDC_ARROW );
/*
		// [!] : no ibeam when normal, ibeam when IME is ON

		extern n_posix_bool n_win_txtbox_is_hovered( n_win_txtbox* );

		if (
			( p->ime_onoff )
			&&
			( p->menu_onoff == n_posix_false )
			&&
			( p->is_hovered_linenum == n_posix_false )
			&&
			( n_win_txtbox_is_hovered( p ) )
			&&
			( p->hwnd == n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) )
		)
		{
			n_win_txtbox_cursor_add( p, IDC_IBEAM );
		} else {
			n_win_txtbox_cursor_add( p, IDC_ARROW );
		}
*/
	} else {
//n_win_txtbox_hwndprintf_literal( p, " 0 " );
//n_win_txtbox_cursor_add( p, IDC_IBEAM ); return;

		extern n_posix_bool n_win_txtbox_is_hovered( n_win_txtbox* );

		n_posix_bool is_hovered = n_win_txtbox_is_hovered( p );

		if ( p->menu_onoff )
		{

			n_win_txtbox_cursor_add( p, IDC_ARROW );

		} else
		if ( is_hovered == n_posix_false )
		{

			n_win_txtbox_cursor_add( p, IDC_ARROW );

		} else {

			if (
				( p->smallbutton_margin == 0 )
				||
				( n_posix_false == IsWindowVisible( n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) ) )
			)
			{
//n_win_txtbox_hwndprintf_literal( p, " 1 " );
				n_win_txtbox_cursor_add( p, IDC_IBEAM );
			} else

			if (
				( p->menu_onoff         == n_posix_false )
				&&
				( p->is_hovered_linenum == n_posix_false )
				&&
				( p->hwnd == n_win_cursor2hwnd_relative( n_win_hwnd_toplevel( p->hwnd ) ) )
			)
			{
//n_win_txtbox_hwndprintf_literal( p, " 2 " );
				n_win_txtbox_cursor_add( p, IDC_IBEAM );
			}

		}

	}


	return;
}

void
n_win_txtbox_grayed( n_win_txtbox *p, n_posix_bool onoff )
{

	if ( p == NULL ) { return; }


	p->is_grayed = onoff;

	if ( onoff )
	{
		p->grayed_onoff = n_posix_true;

		p->color_back_noselect = p->color_back_disabled;
		p->color_back_selected = p->color_sel_focus_off;
	} else {
		p->color_back_noselect = p->color_back__enabled;
	}

	 n_win_txtbox_refresh( p, N_WIN_TXTBOX_GRAYED );


	return;
}

void
n_win_txtbox_caret_reset( n_win_txtbox *p, n_posix_bool show_onoff )
{
//return;

	if ( show_onoff )
	{
		p->caret_blend   = 1.0;
		p->caret_fade_in = n_posix_true;
	} else {
		p->caret_blend   = 0.0;
		p->caret_fade_in = n_posix_false;
	}


	return;
}

void
n_win_txtbox_caret_onoff( n_win_txtbox *p, n_posix_bool onoff )
{

	// [x] : n_win_txtbox_caret_reset() interferes N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF

	if ( p->style_option & N_WIN_TXTBOX_OPTION_CARET_BLINK_OFF )
	{

		if ( onoff )
		{
			//n_win_txtbox_caret_reset( p, n_posix_true );
			n_win_timer_init( p->hwnd, p->caret_timer, GetCaretBlinkTime() );
		} else {
			n_win_timer_exit( p->hwnd, p->caret_timer );
		}

	} else {

		if ( onoff )
		{
			//n_win_txtbox_caret_reset( p, n_posix_true );
			n_win_timer_init( p->hwnd, p->caret_timer, GetCaretBlinkTime() / 20 );
		} else {
			n_win_timer_exit( p->hwnd, p->caret_timer );
		}

	}


	return;
}

void
n_win_txtbox_scaling( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->scale = trunc( n_win_scale( p->hwnd ) );


	return;
}

// internal
s32
n_win_txtbox_horizontal_centering( n_win_txtbox *p )
{

	s32 ret = 0;

	if (
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		&&
		( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_HCENTER )
	)
	{
		n_posix_char *text = n_txt_get( &p->txt, 0 );

		SIZE size = n_win_txtbox_size_text( p, text );
		if ( p->canvas_real_pxl_sx > size.cx )
		{
			ret = ( p->canvas_real_pxl_sx - size.cx ) / 2;
		}
	}


	return ret;
}


