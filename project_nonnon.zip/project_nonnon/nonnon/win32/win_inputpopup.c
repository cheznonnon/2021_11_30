// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_INPUTPOPUP
#define _H_NONNON_WIN32_WIN_INPUTPOPUP




#include "./win.c"

#include "./win_button.c"
#include "./win_popup.c"
#include "./win_txtbox.c"




#define KEY_MAX ( 10 + 26 + 3 )
#define BTN_MAX KEY_MAX


static HWND          n_win_inputpopup_hpopup = NULL;
static HWND          n_win_inputpopup_target = NULL;
static n_win_txtbox *n_win_inputpopup_txtbox = NULL;

static n_posix_bool  n_win_inputpopup_silent_onoff   = n_posix_false;

static n_posix_bool  n_win_inputpopup_nc_button_down = n_posix_false;
static POINT         n_win_inputpopup_point          = { 0,0 };


#define N_WIN_INPUTPOPUP_KILLFOCUS_PHASE_NONE ( 0 )
#define N_WIN_INPUTPOPUP_KILLFOCUS_PHASE_BUSY ( 1 )
#define N_WIN_INPUTPOPUP_KILLFOCUS_PHASE_IN   ( 2 )
#define N_WIN_INPUTPOPUP_KILLFOCUS_PHASE_OUT  ( 3 )

static int n_win_inputpopup_killfocus_phase_cur = N_WIN_INPUTPOPUP_KILLFOCUS_PHASE_NONE;
static int n_win_inputpopup_killfocus_phase_prv = N_WIN_INPUTPOPUP_KILLFOCUS_PHASE_NONE;




static n_posix_char *n_win_inputpopup_keytable_upper[] = {

	n_posix_literal( "0" ),
	n_posix_literal( "1" ),
	n_posix_literal( "2" ),
	n_posix_literal( "3" ),
	n_posix_literal( "4" ),
	n_posix_literal( "5" ),
	n_posix_literal( "6" ),
	n_posix_literal( "7" ),
	n_posix_literal( "8" ),
	n_posix_literal( "9" ),
	n_posix_literal( "A" ),
	n_posix_literal( "B" ),
	n_posix_literal( "C" ),
	n_posix_literal( "D" ),
	n_posix_literal( "E" ),
	n_posix_literal( "F" ),
	n_posix_literal( "G" ),
	n_posix_literal( "H" ),
	n_posix_literal( "I" ),
	n_posix_literal( "J" ),
	n_posix_literal( "K" ),
	n_posix_literal( "L" ),
	n_posix_literal( "M" ),
	n_posix_literal( "N" ),
	n_posix_literal( "O" ),
	n_posix_literal( "P" ),
	n_posix_literal( "Q" ),
	n_posix_literal( "R" ),
	n_posix_literal( "S" ),
	n_posix_literal( "T" ),
	n_posix_literal( "U" ),
	n_posix_literal( "V" ),
	n_posix_literal( "W" ),
	n_posix_literal( "X" ),
	n_posix_literal( "Y" ),
	n_posix_literal( "Z" ),
	n_posix_literal( " " ),
	n_posix_literal( "Caps" ),
	n_posix_literal( "BS" )

};

static n_posix_char *n_win_inputpopup_keytable_lower[] = {

	n_posix_literal( "0" ),
	n_posix_literal( "1" ),
	n_posix_literal( "2" ),
	n_posix_literal( "3" ),
	n_posix_literal( "4" ),
	n_posix_literal( "5" ),
	n_posix_literal( "6" ),
	n_posix_literal( "7" ),
	n_posix_literal( "8" ),
	n_posix_literal( "9" ),
	n_posix_literal( "a" ),
	n_posix_literal( "b" ),
	n_posix_literal( "c" ),
	n_posix_literal( "d" ),
	n_posix_literal( "e" ),
	n_posix_literal( "f" ),
	n_posix_literal( "g" ),
	n_posix_literal( "h" ),
	n_posix_literal( "i" ),
	n_posix_literal( "j" ),
	n_posix_literal( "k" ),
	n_posix_literal( "l" ),
	n_posix_literal( "m" ),
	n_posix_literal( "n" ),
	n_posix_literal( "o" ),
	n_posix_literal( "p" ),
	n_posix_literal( "q" ),
	n_posix_literal( "r" ),
	n_posix_literal( "s" ),
	n_posix_literal( "t" ),
	n_posix_literal( "u" ),
	n_posix_literal( "v" ),
	n_posix_literal( "w" ),
	n_posix_literal( "x" ),
	n_posix_literal( "y" ),
	n_posix_literal( "z" ),
	n_posix_literal( " " ),
	n_posix_literal( "Caps" ),
	n_posix_literal( "BS" )

};


static n_win_button n_win_inputpopup_hbtn[ BTN_MAX ];




// internal
n_posix_bool
n_win_inputpopup_is_error( HWND hpopup, HWND target )
{

	if ( hpopup == NULL ) { return n_posix_true; }
	if ( target == NULL ) { return n_posix_true; }

	if ( n_posix_false == IsWindow( hpopup ) ) { return n_posix_true; }
	if ( n_posix_false == IsWindow( target ) ) { return n_posix_true; }


	return n_posix_false;
}

void
n_win_inputpopup_close_send( HWND hpopup )
{

	n_win_message_send( hpopup, WM_CLOSE, 0,0 );


	return;
}

n_posix_bool
n_win_inputpopup_capslock_onoff( void )
{
	return ( GetKeyState( VK_CAPITAL ) & 0x0001 );
}

void
n_win_inputpopup_autoclose( void )
{

	// [!] : you need to call this function at WM_CLOSE


	HWND hpopup = n_win_inputpopup_hpopup;
	HWND target = n_win_inputpopup_target;


	if ( n_win_inputpopup_is_error( hpopup, target ) ) { return; }


	if ( hpopup ==            GetFocus()   ) { return; }
	if ( hpopup == GetParent( GetFocus() ) ) { return; }


	// [!] : combined version of n_win_is_hovered()

	{

		s32 fx,fy,fsx,fsy; n_win_location_relative( NULL, hpopup, &fx,&fy,&fsx,&fsy );
		s32 tx,ty,tsx,tsy; n_win_location_relative( NULL, target, &tx,&ty,&tsx,&tsy );

		s32  x = n_posix_min_s32(  fx,  tx );
		s32  y = n_posix_min_s32(  fy,  ty );
		s32 sx = n_posix_max_s32( fsx, tsx );
		s32 sy = fsy + tsy;

		if ( n_win_is_hovered_offset( NULL, x,y,sx,sy ) ) { return; }

	}


	n_win_inputpopup_close_send( hpopup );


	return;
}

// internal
void
n_win_inputpopup_automove( HWND hpopup, HWND target )
{

	if ( n_win_inputpopup_is_error( hpopup, target ) ) { return; }


	// [!] : don't use GetClientRect() : border is needed


	s32 x,y,sx,sy;


	n_win_location_relative( NULL, target, &x, &y, NULL, &sy );

	y += sy;

	n_win_size( hpopup, &sx, &sy );


	SetWindowPos( hpopup, NULL, x,y,sx,sy, SWP_NOACTIVATE | SWP_DRAWFRAME );


	return;
}

// internal
LRESULT CALLBACK
n_win_inputpopup_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const int keybind[] = {

		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
		'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
		'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
		'U', 'V', 'W', 'X', 'Y', 'Z',
		VK_SPACE, VK_CAPITAL, VK_BACK

	};


	static s32 border;
	static s32 size;
	static s32 csx = 0;
	static s32 csy = 0;
	static s32 ox  = 0;
	static s32 oy  = 0;
	static s32 gap = 0;


	n_posix_char *s;
	s32           i,tmp, x,y;


	switch( msg ) {


	case WM_CREATE :


		// Global

		n_win_stdsize( hwnd, &size, NULL, NULL );

		border = GetSystemMetrics( SM_CXBORDER );

		csx = ( size * 10 ) + ( border * 2 );
		csy = ( size *  4 ) + ( border * 2 );


		// Window

		n_win_init_literal( hwnd, "", "", "" );


		// [Needed] : Win2000 : fade needs this
		DragAcceptFiles( hwnd, n_posix_true );


		n_win_topmost( hwnd, n_posix_true );

		n_win_style_dropshadow_onoff( hwnd, n_posix_true );


		// Style

		if ( n_win_fluent_ui_onoff )
		{
			n_win_style_new( hwnd, WS_POPUP );

			ox = GetSystemMetrics( SM_CXBORDER );
			oy = GetSystemMetrics( SM_CYBORDER );

			gap = GetSystemMetrics( SM_CXBORDER );
			csx += gap * 9;

			csx += ox * 2;
			csy += oy * 2;

			n_win_fluent_ui_roundrect_region( hwnd, csx, csy, n_win_fluent_ui_round_param() );
		} else {
			ox = oy = gap = 0;

			n_win_style_new( hwnd, WS_POPUP | WS_BORDER );
		}


		// Buttons

//n_win_hwndprintf_literal( n_win_inputpopup_target, "%x", GetKeyState( VK_CAPITAL ) );

		n_posix_bool number = n_win_property_get_literal( n_win_inputpopup_target, "Number" );
		DWORD        style  = n_win_style_get( n_win_inputpopup_target );
		n_posix_bool caps   = n_win_inputpopup_capslock_onoff();

		i = 0;

		if ( n_win_fluent_ui_onoff )
		{
			x = border + ox;
			y = border + oy;
		} else {
			x = y = 0;
		}

		while( 1 )
		{
//break;
			if ( caps )
			{
				s = n_win_inputpopup_keytable_upper[ i ];
			} else {
				s = n_win_inputpopup_keytable_lower[ i ];
			}

			n_win_button_zero( &n_win_inputpopup_hbtn[ i ] );
			n_win_button_init( &n_win_inputpopup_hbtn[ i ], hwnd, s, PBS_NORMAL );


			if( i <= ( KEY_MAX - 3 ) )
			{
				tmp = size;
			} else {
				tmp = size + ( size / 2 );
				if ( ( i + 1 ) == BTN_MAX ) { tmp = csx - ( border * 2 ) - x; }
			}

			n_win_move_simple( n_win_inputpopup_hbtn[ i ].hwnd, x,y, tmp,size, n_posix_false );


			if (
				( ( style & ES_NUMBER )||( number ) )
				&&
				( ( i >= 10 )&&( i <= ( BTN_MAX - 2 ) ) )
			)
			{
				n_win_inputpopup_hbtn[ i ].active_onoff = n_posix_false;
			} else {
				n_win_inputpopup_hbtn[ i ].active_onoff = n_posix_true;
			}


			x += tmp + gap;
			if ( ( i % 10 ) == 9 )
			{
				if ( n_win_fluent_ui_onoff )
				{
					x = border + ox;
				} else {
					x = 0;
				}

				y += size;
			}


			i++;
			if ( i >= BTN_MAX ) { break; }
		}


		// Display

		n_win_move_simple( hwnd, 0,0, csx,csy, n_posix_false );
		n_win_inputpopup_automove( hwnd, n_win_inputpopup_target );

//ShowWindowAsync( hwnd, SW_SHOWNA );break;

		{

#ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

			// [x] : n_AW_BLEND : draw error

			n_posix_bool onoff = n_posix_false;
			SystemParametersInfo( SPI_GETCOMBOBOXANIMATION, 0, &onoff, 0 );

			if ( ( onoff ) )//&&( n_sysinfo_version_vista_or_later() ) )
			{

				n_win_inputpopup_killfocus_phase_prv = n_win_inputpopup_killfocus_phase_cur;
				n_win_inputpopup_killfocus_phase_cur = N_WIN_INPUTPOPUP_KILLFOCUS_PHASE_BUSY;

				n_win_button_printclient_onoff = n_posix_true;

				int aw = n_AW_SLIDE | n_AW_VER_POSITIVE;

				// [x] : Win2000 : n_AW_SLIDE : not wroking : when using region

				if ( n_win_fluent_ui_onoff )
				{
					if ( n_posix_false == n_sysinfo_version_xp_or_later() )
					{
						aw = n_AW_BLEND | n_AW_VER_POSITIVE;
					}
				}

				n_posix_bool ret = n_win_animatewindow( hwnd, 0, aw );
				if ( ret ) { ShowWindow( hwnd, SW_NORMAL ); }

				n_win_button_printclient_onoff = n_posix_false;

				n_win_inputpopup_killfocus_phase_cur = N_WIN_INPUTPOPUP_KILLFOCUS_PHASE_IN;

			} else {

				ShowWindowAsync( hwnd, SW_SHOWNA );

			}

#else  // #ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

			ShowWindowAsync( hwnd, SW_SHOWNA );

#endif // #ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

		}

	break;


	case WM_MOUSEACTIVATE :
//n_posix_debug_literal( " ! " );

		return MA_NOACTIVATE;//MA_NOACTIVATEANDEAT;

	break;


	case WM_COMMAND :

		i = 0;
		while( 1 )
		{//break;

			if ( (HWND) lparam == n_win_inputpopup_hbtn[ i ].hwnd )
			{

				if ( n_win_inputpopup_target != GetFocus() )
				{
					SetFocus( n_win_inputpopup_target );
				}

				n_win_input( 0, keybind[ i ] );


				break;
			}

			i++;
			if ( i >= BTN_MAX ) { break; }
		}

		//return 0;

	break;


	case WM_KILLFOCUS :

		n_win_inputpopup_autoclose();

	break;


	case WM_CLOSE :
	{

		if ( n_win_inputpopup_silent_onoff == n_posix_false )
		{

#ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

			n_posix_bool onoff = n_posix_false;
			SystemParametersInfo( SPI_GETMENUFADE, 0, &onoff, 0 );

			if ( onoff )
			{
				n_win_inputpopup_killfocus_phase_prv = n_win_inputpopup_killfocus_phase_cur;
				n_win_inputpopup_killfocus_phase_cur = N_WIN_INPUTPOPUP_KILLFOCUS_PHASE_BUSY;

				int aw = n_AW_HIDE | n_AW_BLEND | n_AW_VER_NEGATIVE;
				n_win_animatewindow( hwnd, 0, aw );

				n_win_inputpopup_killfocus_phase_cur = N_WIN_INPUTPOPUP_KILLFOCUS_PHASE_OUT;

			}

#endif // #ifdef _H_NONNON_WIN32_WIN_AMIMATEWINDOW

		} else {

			n_win_inputpopup_silent_onoff = n_posix_false;

		}


		if ( n_win_inputpopup_txtbox != NULL )
		{
			n_win_txtbox_on_focus( n_win_inputpopup_txtbox, n_posix_false );
		}


		n_win_inputpopup_hpopup = NULL;
		n_win_inputpopup_target = NULL;
		n_win_inputpopup_txtbox = NULL;


		int i = 0;
		while( 1 )
		{

			n_win_button_exit( &n_win_inputpopup_hbtn[ i ] );

			i++;
			if ( i >= BTN_MAX ) { break; }
		}


		DestroyWindow( hwnd );

	}
	break;	


	} // switch


	i = 0;
	while( 1 )
	{//break;

		n_win_button_proc( hwnd, msg, wparam, lparam, &n_win_inputpopup_hbtn[ i ] );

		i++;
		if ( i >= BTN_MAX ) { break; }
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

void
n_win_inputpopup_open( HWND hwnd_parent, HWND hwnd_target )
{

	if ( hwnd_target != n_win_inputpopup_target )
	{
		n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
	}

	if ( n_win_inputpopup_hpopup == NULL )
	{
		n_win_inputpopup_target = hwnd_target;
		n_win_gui( hwnd_parent, N_WIN_GUI_WINDOW, n_win_inputpopup_wndproc, &n_win_inputpopup_hpopup );

		if ( n_win_inputpopup_target != GetFocus() ) { SetFocus( hwnd_target ); }
	}

	return;
}

void
n_win_inputpopup_open_txtbox( HWND hwnd_parent, n_win_txtbox *txtbox_target )
{

	if ( txtbox_target->hwnd != n_win_inputpopup_target )
	{
		n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
	}

	if ( n_win_inputpopup_hpopup == NULL )
	{
		n_win_inputpopup_target = txtbox_target->hwnd;
		n_win_inputpopup_txtbox = txtbox_target;
		n_win_gui( hwnd_parent, N_WIN_GUI_WINDOW, n_win_inputpopup_wndproc, &n_win_inputpopup_hpopup );

		if ( n_win_inputpopup_target != GetFocus() )
		{
			SetFocus( n_win_inputpopup_target );
		}

		n_win_txtbox_on_focus( n_win_inputpopup_txtbox, n_posix_true );
	}

	return;
}

void
n_win_inputpopup_close( void )
{

	if ( n_win_inputpopup_hpopup != NULL )
	{
		n_win_inputpopup_autoclose();
	}

	return;
}

void
n_win_inputpopup_close_forced( void )
{

	if ( n_win_inputpopup_hpopup != NULL )
	{
		n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
	}

	return;
}

void
n_win_inputpopup_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND target )
{

	switch( msg ) {


	case WM_COMMAND :

		if ( target != (HWND) lparam )
		{

			if ( n_posix_false == IsWindow( n_win_inputpopup_hpopup ) ) { break; }

			if ( n_win_class_is_same_literal( (HWND) lparam, "Edit" ) ) { break; }

			n_win_inputpopup_close_send( n_win_inputpopup_hpopup );

		} else
		if ( EN_SETFOCUS == HIWORD( wparam ) )
		{

			n_win_inputpopup_open( hwnd, target );

		} else
		if ( EN_KILLFOCUS == HIWORD( wparam ) )
		{

			n_win_inputpopup_close();

		}// else

	break;


	case WM_MOVE :
	case WM_SIZE :
	//case WM_MOUSEMOVE   :
	//case WM_NCMOUSEMOVE :

		//n_win_inputpopup_autoclose();
		n_win_inputpopup_automove( n_win_inputpopup_hpopup, n_win_inputpopup_target );

	break;


	case WM_NCLBUTTONDOWN :
	case WM_NCMBUTTONDOWN :
	case WM_NCRBUTTONDOWN :
//n_win_hwndprintf_literal( hwnd, " %d ", n_win_inputpopup_nc_button_down );

		if ( n_win_inputpopup_nc_button_down == n_posix_false )
		{
			n_win_inputpopup_nc_button_down = n_posix_true;
			GetCursorPos( &n_win_inputpopup_point );
		}

	break;

	case WM_LBUTTONDOWN :
	case WM_MBUTTONDOWN :
	case WM_RBUTTONDOWN :
//n_posix_debug_literal( "" );

		if ( n_win_inputpopup_is_error( n_win_inputpopup_hpopup, n_win_inputpopup_target ) ) { break; }

		n_win_inputpopup_close_send( n_win_inputpopup_hpopup );

	break;


	case WM_KEYDOWN :

		if ( (int) wparam == VK_CAPITAL )
		{

			n_posix_bool caps = n_win_inputpopup_capslock_onoff();

			int i = 0;
			while( 1 )
			{

				n_posix_char *s;

				if ( caps )
				{
					s = n_win_inputpopup_keytable_upper[ i ];
				} else {
					s = n_win_inputpopup_keytable_lower[ i ];
				}

				n_win_hwndprintf_literal( n_win_inputpopup_hbtn[ i ].hwnd, "%s", s );

				i++;
				if ( i >= BTN_MAX ) { break; }
			}

		}

	break;


	case WM_CLOSE :

		// [x] : prevent GDI handle leak : closed when hpopup is ON
		//
		//	you need to send WM_CLOSE manually

	break;


	} // switch


	if ( n_win_inputpopup_nc_button_down )
	{

		int threshold_sx = 0;
		int threshold_sy = 0;
		n_win_mouse_threshold( hwnd, &threshold_sx, &threshold_sy );

		POINT point; GetCursorPos( &point );

		if (
			( threshold_sx > abs( n_win_inputpopup_point.x - point.x ) )
			||
			( threshold_sy > abs( n_win_inputpopup_point.y - point.y ) )
		)
		{

			if (

				( n_posix_false == n_win_is_input( VK_LBUTTON ) )
				&&
				( n_posix_false == n_win_is_input( VK_MBUTTON ) )
				&&
				( n_posix_false == n_win_is_input( VK_RBUTTON ) )
			)
			{
				n_win_inputpopup_nc_button_down = n_posix_false;

				if ( n_posix_false == n_win_inputpopup_is_error( n_win_inputpopup_hpopup, n_win_inputpopup_target ) )
				{
					n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
				}
			}

		} else {

			n_win_inputpopup_nc_button_down = n_posix_false;

		}

	}



	return;
}

void
n_win_inputpopup_proc_light( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND target )
{

	switch( msg ) {


	case WM_MOVE :
	case WM_SIZE :
	//case WM_MOUSEMOVE   :
	//case WM_NCMOUSEMOVE :

		//n_win_inputpopup_autoclose();
		n_win_inputpopup_automove( n_win_inputpopup_hpopup, n_win_inputpopup_target );

	break;


	case WM_NCLBUTTONUP :
	case WM_NCMBUTTONUP :
	case WM_NCRBUTTONUP :
	case WM_LBUTTONDOWN :
	case WM_MBUTTONDOWN :
	case WM_RBUTTONDOWN :

		if ( n_win_inputpopup_target != n_win_cursor2hwnd_relative( hwnd ) )
		{
			n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
		}

	break;


	case WM_KEYDOWN :

		if ( (int) wparam == VK_CAPITAL )
		{

			n_posix_bool caps = n_win_inputpopup_capslock_onoff();

			int i = 0;
			while( 1 )
			{

				n_posix_char *s;

				if ( caps )
				{
					s = n_win_inputpopup_keytable_upper[ i ];
				} else {
					s = n_win_inputpopup_keytable_lower[ i ];
				}

				n_win_hwndprintf_literal( n_win_inputpopup_hbtn[ i ].hwnd, "%s", s );

				i++;
				if ( i >= BTN_MAX ) { break; }
			}

		}

	break;


	case WM_ACTIVATE :

		if ( wparam == WA_INACTIVE )
		{
//n_win_hwndprintf_literal( n_win_hwnd_toplevel( hwnd ), " %x %x %x ", lparam, hwnd, n_win_hwnd_toplevel( hwnd ) );

			if ( (HWND) lparam == NULL )
			{
				n_win_inputpopup_close_send( n_win_inputpopup_hpopup );
			}

		}

	break;


	} // switch


	return;
}

void
n_win_inputpopup_patch( HWND hwnd, UINT msg, WPARAM *wparam, LPARAM *lparam )
{

	HWND hpopup = n_win_inputpopup_hpopup;


	// [!] : suppress gray-out when "hpopup" is active

	switch( msg ) {

	case WM_NCACTIVATE :

		if ( (*wparam) == n_posix_false )
		{
			(*wparam) = IsWindow( hpopup );
		}

	break;

	} // switch


	// [!] : restoring is needed when "hpopup" is closed

	static n_posix_bool onoff = n_posix_false;

	if ( IsWindow( hpopup ) )
	{

		onoff = n_posix_true;

	} else
	if ( onoff )
	{

		onoff = n_posix_false;


		HWND         h       = n_win_cursor2hwnd();
		n_posix_bool restore = n_posix_false;


		if (
			( hwnd == h )
			||
			( IsChild(   hwnd, h ) )
			||
			( IsChild( hpopup, h ) )
		)
		{
			restore = n_posix_true;
		}


		n_win_message_send( hwnd, WM_NCACTIVATE, restore, 0 );


		// [!] : Win95 : hangup
		//
		//	don't use SetActiveWindow( hwnd );

		if ( restore ) { SetFocus( n_win_cursor2hwnd() ); }

	}


	return;
}


#undef KEY_MAX
#undef BTN_MAX


#endif // _H_NONNON_WIN32_WIN_INPUTPOPUP

