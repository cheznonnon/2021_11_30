// Mau 0.7
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"


#include "../nonnon/neutral/dir.c"
#include "../nonnon/neutral/filer.c"
#include "../nonnon/neutral/path.c"
#include "../nonnon/neutral/txt.c"




#define DEFAULT_MENU_OFFSET 3




void
n_mau_cls( void )
{

#ifdef N_POSIX_PLATFORM_WINDOWS

	n_posix_system( n_posix_literal( "cls" ) );

#else

	n_posix_printf( n_posix_literal( "\x1b[2J" ) );

#endif


	return;
}

void
n_mau_input_wait( n_posix_char *str, int length )
{

	n_path_zero( str );


	fflush( stdin );

	while( NULL == n_posix_fgets( str, length - 1, stdin ) );


	return;
}

int
n_mau_input_number( void )
{

	n_posix_char str[ N_PATH_MAX ];
	int          ret;


	n_mau_input_wait( str, N_PATH_MAX );


	if ( str[ 0 ] == N_STRING_CHAR_LF )
	{

		// [!] : enter is pressed

		ret = -1;

	} else
	if ( 0 == n_string_char_is_digit( str[ 0 ] ) )
	{

		// [!] : not number keys

		ret = -2;

	} else {

		// [!] : rest -> convert

		ret = n_posix_atoi( str );

	}

	n_posix_printf_literal( "\n" );


	return ret;
}

void
n_mau_input_string( n_posix_char *str, int len )
{

	if ( str == NULL ) { return; }


	n_mau_input_wait( str, len );


	// [!] : remove LF

	n_string_terminate( str, n_posix_strlen( str ) - 1 );


	n_posix_printf_literal( "\n" );


	return;
}

#define n_mau_error_literal( str_error ) n_mau_error( n_posix_literal( str_error ) )

void
n_mau_error( const n_posix_char *str_error )
{

	n_posix_printf_literal( "Please check" );
	n_posix_printf_literal( "\n" );
	n_posix_printf_literal( "Error : %s", str_error );
	n_posix_printf_literal( "\n" );

	n_posix_printf_literal( "\n" );
	n_posix_printf_literal( "press any key >>" );

	n_mau_input_number();


	return;
}

n_posix_bool
n_mau_pocket_is_empty( const n_posix_char *pocket )
{

	if ( n_posix_false == n_string_is_empty( pocket ) ) { return n_posix_false; }


	n_posix_printf_literal( "sorry, the Pocket is empty\n" );


	n_posix_printf_literal( "\n" );
	n_posix_printf_literal( "press any key >>" );

	n_mau_input_number();


	return n_posix_true;
}

void
n_mau_emptyfile( const n_posix_char *fname )
{

//n_posix_printf_literal( "%s\n", fname );

	if ( n_posix_stat_is_exist( fname ) ) 
	{

		n_mau_error_literal( "n_posix_stat_is_exist()" );

		return;
	}


	FILE *fp = n_posix_fopen_write( fname );
	if ( fp == NULL )
	{

		n_mau_error_literal( "n_posix_fopen_write()" );

		return;
	}
	n_posix_fclose( fp );


	return;
}

void
n_mau_emptydir( const n_posix_char *fname )
{

#ifdef N_POSIX_PLATFORM_WINDOWS

	int ret = n_posix_mkdir( fname );

#else

	int ret = n_posix_mkdir( fname, N_POSIX_PERMISSION_DEFAULT );

#endif

	if ( ret == -1 ) { n_mau_error_literal( "n_posix_mkdir()" ); }


	return;
}

void
n_mau_remove( const n_posix_char *fname )
{

	n_posix_printf_literal( "Really OK?\n" );
	n_posix_printf_literal( "1 : yes\n" );
	n_posix_printf_literal( "2 : no\n" );
	n_posix_printf_literal( ">>" );

	int number = n_mau_input_number();
	if ( number != 1 ) { return; }


	int ret = n_filer_remove( fname );
	if ( ret ) { n_mau_error_literal( "n_filer_remove()" ); }


	return;
}

void
n_mau_version( void )
{

	n_posix_printf_literal( "\n" );
	n_posix_printf_literal( "+++ Mau 0.7 By Nonnon +++\n" );
	n_posix_printf_literal( "(c) nonnon all rights reserved.\n" );
	n_posix_printf_literal( "License : GPL http://www.gnu.org/copyleft/gpl.html\n" );
	n_posix_printf_literal( "\n" );


	return;
}

void
n_mau_info( n_posix_char *fname )
{

	if ( n_posix_false == n_posix_stat_is_exist( fname ) )
	{

		n_mau_error_literal( "n_posix_stat_is_exist()" );

		return;
	}


	n_posix_printf_literal( "\n" );
	n_posix_printf_literal( "%s\n", fname );
	n_posix_printf_literal( "\n" );


	if ( n_posix_stat_is_file( fname ) )
	{
		n_posix_printf_literal( "Size : %6d Byte\n", (int) n_posix_stat_size( fname ) );
	}


	// [!] : nec pc98 : NULL check needed

	time_t a = n_posix_stat_atime( fname );
	time_t c = n_posix_stat_ctime( fname );
	time_t m = n_posix_stat_mtime( fname );

	n_posix_char *str_a = n_posix_ctime( &a );
	n_posix_char *str_c = n_posix_ctime( &c );
	n_posix_char *str_m = n_posix_ctime( &m );

	if ( str_a == NULL ) { str_a = n_posix_literal( "N/A\n" ); }
	if ( str_c == NULL ) { str_c = n_posix_literal( "N/A\n" ); }
	if ( str_m == NULL ) { str_m = n_posix_literal( "N/A\n" ); }


	n_posix_printf_literal( "Last Access : %26s", str_a );
	n_posix_printf_literal( "Last Change : %26s", str_c );
	n_posix_printf_literal( "Last Modify : %26s", str_m );


	n_posix_printf_literal( "\n" );


	return;
}

// internal
void
n_mau_dirlist( n_dir *list, const n_posix_char *dir, int offset )
{

	n_dir_load( list, dir );

//n_posix_printf_literal( "%d + %d\n", list->dir, list->file ); return;

	if ( 0 == n_dir_all( list ) ) { return; }


	n_dir_sort( list );


	int line = 0;

	int i = 0;
	while( 1 )
	{

		n_posix_printf_literal( "%5d : ", i + offset );

		if ( n_posix_stat_is_file( n_dir_name( list, i ) ) )
		{
			n_posix_printf_literal( "FILE : " );
		} else {
			n_posix_printf_literal( "DIR  : " );
		}

		n_posix_printf_literal( "%s", n_dir_name( list, i ) );
		n_posix_printf_literal( "\n" );

//n_posix_debug( n_dir_name( list, i ) );

//n_posix_printf_literal( "Debug >" );
//n_mau_input_number();


		line++;
		if ( line >= ( 25 - 3 ) )
		{
//break;

			line = 0;


			n_posix_printf_literal( "\n" );

			while( 1 )
			{

				n_posix_printf_literal( "enter key to continue, else stop >" );

				if ( -1 == n_mau_input_number() )
				{
					break;
				} else {
					return;
				}

			}

		}


		i++;
		if ( i >= n_dir_all( list ) ) { break; }

	} // while( 1 )


	return;
}

void
n_mau_textviewer( const n_posix_char *fname )
{

	n_txt txt;
	n_txt_zero( &txt );
	if ( n_txt_load( &txt, fname ) ) { return; }


	int i  = 0;
	int ii = 0;
	while( 1 )
	{

		n_posix_printf_literal( "%s\n", (n_posix_char*) txt.line[ i ] );

		i++;
		if ( i >= txt.sy ) { break; }

		ii++;
		if ( ii >= ( 25 - 3 ) )
		{

			ii = 0;

			n_posix_printf_literal( "\n" );

			while( 1 )
			{

				n_posix_printf_literal( "enter key to continue, else stop >" );

				if ( -1 == n_mau_input_number() )
				{
					break;
				} else {
					return;
				}

			}

		}

	}


	n_posix_printf_literal( "\n" );
	n_posix_printf_literal( "press any key >>" );

	n_mau_input_number();


	return;
}

int
main( void )
{

	// [Mechanism] : <limits.h>
	//
	//	PATH_MAX :    259
	//	SHRT_MAX :  32767


	n_dir        list;

	n_posix_char    dir[ N_PATH_MAX ];
	n_posix_char pocket[ N_PATH_MAX ];

	int          menu_offset;
	int          choice;


	n_dir_zero( &list );

	n_path_zero( pocket );


	while( 1 ) { // main loop


	n_path_getcwd( dir );


	menu_offset = DEFAULT_MENU_OFFSET;


#ifdef N_POSIX_PLATFORM_WINDOWS

	// Windows only : "C:\" => "C:"

	if ( 3 == n_posix_strlen( dir ) )
	{

		n_string_terminate( dir, n_posix_strlen( dir ) - 1 );

		menu_offset--;
	}

#else

	// [!] : root directory

	if ( 1 == n_posix_strlen( dir ) )
	{
		menu_offset--;
	}

#endif


	n_posix_printf_literal( "\n" );
	n_posix_printf_literal( "if you meet troubles, press ctrl+c\n" );
	n_posix_printf_literal( "\n" );

	n_posix_printf_literal( "------------------------------\n" );
	n_posix_printf_literal( "%s\n", dir );
	n_posix_printf_literal( "------------------------------\n" );
	n_posix_printf_literal( "    0 : exit\n" );
	n_posix_printf_literal( "------------------------------\n" );
	n_posix_printf_literal( "    1 : menu\n" );
	if ( menu_offset == DEFAULT_MENU_OFFSET )
	{
		n_posix_printf_literal( "    2 : up\n" );
	}
	n_posix_printf_literal( "------------------------------\n" );
	n_mau_dirlist( &list, dir, menu_offset );
	n_posix_printf_literal( "------------------------------\n" );

	n_posix_printf_literal( "\n" );
	n_posix_printf_literal( "number >>" );
	choice = n_mau_input_number();

//n_posix_printf_literal( "input       : %d\n",      choice );
//n_posix_printf_literal( "menu_offset : %d\n", menu_offset );


	if ( choice == 0 )
	{

		break;

	} else
	if ( choice == 1 )
	{

		n_posix_char str[ N_PATH_MAX ];


		n_mau_cls();

		while( 3 )
		{

			n_mau_version();

			n_posix_printf_literal( "------------------------------\n" );
			n_posix_printf_literal( "0 : back\n" );
			n_posix_printf_literal( "------------------------------\n" );
			n_posix_printf_literal( "1 : new file\n" );
			n_posix_printf_literal( "2 : new directory\n" );
			n_posix_printf_literal( "------------------------------\n" );
			n_posix_printf_literal( "3 : copy : %s\n", pocket );
			n_posix_printf_literal( "4 : move : %s\n", pocket );
			n_posix_printf_literal( "------------------------------\n" );
			n_posix_printf_literal( "9 : change directory directly\n" );
			n_posix_printf_literal( "------------------------------\n" );

			n_posix_printf_literal( "\n" );
			n_posix_printf_literal( "number >>" );
			choice = n_mau_input_number();


			if ( choice == 0 )
			{

				break;

			} else

			if ( choice == 1 )
			{ 

				n_posix_printf_literal( "file name >>" );
				n_mau_input_string( str, N_PATH_MAX );

				n_mau_emptyfile( str );


				break;

			} else

			if ( choice == 2 )
		 	{ 

				n_posix_printf_literal( "directory name >>" );
				n_mau_input_string( str, N_PATH_MAX );

				n_mau_emptydir( str );


				break;

			} else

			if ( choice == 3 )
			{

				if ( n_mau_pocket_is_empty( pocket ) ) { break; }


				n_path_name( pocket, str );
//n_posix_printf_literal( "NAME : %s\n", str );
//n_posix_printf_literal( "DIR  : %s\n", dir );
				n_path_maker( dir, str, str );
//n_posix_printf_literal( "FROM : %s\n", pocket );
//n_posix_printf_literal( "TO   : %s\n", str );
//break;

				if ( n_filer_copy( pocket, str ) )
				{
					n_mau_error_literal( "n_filer_copy()" );
				}


				break;

			} else

			if ( choice == 4 )
			{

				if ( n_mau_pocket_is_empty( pocket ) ) { break; }


				n_path_name( pocket, str );
//n_posix_printf_literal( "NAME : %s\n", str );
//n_posix_printf_literal( "DIR  : %s\n", dir );
				n_path_maker( dir, str, str );
//n_posix_printf_literal( "FROM : %s\n", pocket );
//n_posix_printf_literal( "TO   : %s\n", str );
//break;

				if ( n_path_rename( pocket, str ) )
				{
					n_mau_error_literal( "n_path_rename()" );
				}


				break;

			} else

			if ( choice == 9 )
			{

				n_posix_printf_literal( "warp! >>" );
				n_mau_input_string( str, N_PATH_MAX );

				n_path_chdir( str );

				break;

			}// else


			n_mau_cls();

		} // while( 3 )

	} else

	if (
		( DEFAULT_MENU_OFFSET == menu_offset )
		&&
		( choice == 2 )
	)
	{

		n_path_chdir( N_STRING_DOTDOT );

	} else

	if (
		( ( choice - menu_offset ) >= 0 )
		&&
		( ( choice - menu_offset ) <  n_dir_all( &list ) )
	)
	{

		n_posix_char fname[ N_PATH_MAX ];
		int          type;


		n_mau_cls();

		n_path_maker( dir, n_dir_name( &list, choice - menu_offset ), fname );
		type = n_posix_stat_type( fname );

		while( 3 )
		{

			if ( type == N_POSIX_STAT_TYPE_NOTEXIST )
			{

				n_mau_error_literal( "n_posix_stat_type()" );

				break;
			}


			n_mau_info( fname );

			n_posix_printf_literal( "------------------------------\n" );
			n_posix_printf_literal( "0 : back\n" );
			n_posix_printf_literal( "------------------------------\n" );
			if ( type == N_POSIX_STAT_TYPE_FILE )
			{
				n_posix_printf_literal( "1 : text viewer\n" );
			} else {
				n_posix_printf_literal( "1 : move\n" );
			}
			n_posix_printf_literal( "2 : pocket\n" );
			n_posix_printf_literal( "3 : rename\n" );
			n_posix_printf_literal( "4 : delete\n" );
			n_posix_printf_literal( "------------------------------\n" );

			n_posix_printf_literal( "\n" );
			n_posix_printf_literal( "number >>" );
			choice = n_mau_input_number();


			if ( choice == 0 )
			{

				break;

			} else

			if ( choice == 1 )
			{

				if ( type == N_POSIX_STAT_TYPE_FILE )
				{
					n_mau_textviewer( fname );
				} else {
					n_path_chdir( fname );
				}


				break;

			} else

			if ( choice == 2 )
			{

				n_string_copy( fname, pocket );


				break;

			} else

			if ( choice == 3 )
			{

				n_posix_char str[ N_PATH_MAX ];


				n_posix_printf_literal( "new name >>" );
				n_mau_input_string( str, N_PATH_MAX );
//n_posix_printf_literal( "%s\n", str );

				if ( -1 == n_posix_rename( fname, str ) )
				{
					n_mau_error_literal( "n_posix_rename()" );
				}


				break;

			} else

			if ( choice == 4 )
			{

				n_mau_remove( fname );


				break;

			}// else


			n_mau_cls();

		} // while( 3 )

	}


	n_mau_cls();


	} // while( 1 ) : main loop


	n_dir_free( &list );


	return 0;
}

